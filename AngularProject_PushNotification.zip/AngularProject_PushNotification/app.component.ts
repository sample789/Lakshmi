import {
  Component,
  OnInit,
  EventEmitter,
  Output
} from '@angular/core';
import {
  PushNotificationsService
} from './push.notification.service';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers:[PushNotificationsService]
})

export class AppComponent implements OnInit {
  public title: string = 'Angular_PushNotifications!';
  constructor(private _notificationService: PushNotificationsService) {
      this._notificationService.requestPermission();
  }
  ngOnInit() {}
  notify() {
      let data: Array < any >= [];
      data.push({
          'title': 'Approval',
          'alertContent': 'This is First Alert -- By Narasimha'
      });
      data.push({
          'title': 'Request',
          'alertContent': 'This is Second Alert -- By Lakshmi'
      });
      data.push({
          'title': 'Leave Application',
          'alertContent': 'This is Third Alert -- By Lakshinarasimha'
      });
      data.push({
          'title': 'Approval',
          'alertContent': 'This is Fourth Alert -- By Narasimha'
      });
      data.push({
          'title': 'To Do Task',
          'alertContent': 'This is Fifth Alert -- By Pandu'
      });
      this._notificationService.generateNotification(data);
  }
}

